from django.shortcuts import render
import pandas as pd
# Create your views here.

def indexPage(request):
    df = pd.read_csv('https://raw.githubusercontent.com/Aiyms/Dashboard/main/dataset.csv', sep=';')
    df.columns = ['Date', 'Sales', 'Time']
    dfc = pd.read_csv('https://raw.githubusercontent.com/Aiyms/Dashboard/main/dataset%20cancelled.csv', sep=';')
    dfc.columns = ['Date', 'Time', 'Cancelled']
    data = df.merge(dfc)

    barPlotData = data.groupby(["Date", "Time"])["Sales", 'Cancelled'].sum().reset_index()
    barPlotData.columns = ['date', 'time', 'sales', 'cancelled']
    dates = barPlotData['date'].values.tolist()
    sales = barPlotData['sales'].values.tolist()
    time = barPlotData['time'].values.tolist()
    cancelled = barPlotData['cancelled'].values.tolist()
    context = {'dates': dates, 'sales': sales, 'time': time, 'cancelled': cancelled}

    return render(request, 'index.html', context)
